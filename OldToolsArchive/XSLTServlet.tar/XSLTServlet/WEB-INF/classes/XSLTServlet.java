import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class XSLTServlet extends HttpServlet {
  
  public final static String FS = System.getProperty("file.separator"); 

  // Respond to HTTP GET requests from browsers.
  public void doGet (HttpServletRequest request,
                     HttpServletResponse response)
    throws ServletException, java.io.IOException {

    // Set content type for HTML.
    response.setContentType("text/html; charset=UTF-8");    

    // Output goes to the response PrintWriter.
    java.io.PrintWriter out = response.getWriter();

    try {	
      javax.xml.transform.TransformerFactory tFactory = 
                javax.xml.transform.TransformerFactory.newInstance();

      //get the real path for xml and xsl files.
      String ctx = getServletContext().getRealPath("") + FS;        

      // Get the XML input document and the stylesheet, both in the servlet
      // engine document directory.
      javax.xml.transform.Source xmlSource = 
                new javax.xml.transform.stream.StreamSource
                             (new java.net.URL("file", "", ctx + "foo.xml").openStream());
      javax.xml.transform.Source xslSource = 
                new javax.xml.transform.stream.StreamSource
                             (new java.net.URL("file", "", ctx + "foo.xsl").openStream());
      // Generate the transformer.
      javax.xml.transform.Transformer transformer = 
                             tFactory.newTransformer(xslSource);

      // Perform the transformation, sending the output to the response.
      transformer.transform(xmlSource, 
                           new javax.xml.transform.stream.StreamResult(out));

    // If an Exception occurs, return the error to the client.
    } catch (Exception e) {
      out.write(e.getMessage());
      e.printStackTrace(out);    
    }

    // Close the PrintWriter.
    out.close();
  }  
}
